interface ICustomer {
    id: string;
    name: string;
    username: string;
    email: string;
    address: string;
    phone: string;
    website: string;
    company: string;
    avatar: string;
}

export class Main {
    constructor() {
        const button = document.getElementById("populate") as HTMLButtonElement;
        button.onclick = () => this.populateData();


    }

    public async populateData() {
        let tableBody = <HTMLElement> document.getElementById("table-body");
        let url = "https://cs4350.herokuapp.com/demo/all";
        this.loadData(url);
        let customerData = await this.loadData(url);
        tableBody.innerHTML = this.createHtmlFromArray(customerData);
        console.log("populate data");
    }

    public async loadData(url: string): Promise<ICustomer[]> {
        const response = await fetch(url);
        const json = await response.json();
        return json as ICustomer[];
    }

    public createHtmlFromArray(dataArray: ICustomer[]): string {
        let listHtml = "";
        let template = document.getElementById("table-template");
        let templateHtml = template.innerHTML;

        for (let index = 0; index < dataArray.length; index++) {
            listHtml += templateHtml
                .replace(/{{id}}/g, dataArray[index].id)
                .replace(/{{name}}/g, dataArray[index].name)
                .replace(/{{username}}/g, dataArray[index].username)
                .replace(/{{email}}/g, dataArray[index].email)
                .replace(/{{address}}/g, dataArray[index].address)
                .replace(/{{phone}}/g, dataArray[index].phone)
                .replace(/{{website}}/g, dataArray[index].website)
                .replace(/{{company}}/g, dataArray[index].company)
                .replace(/{{avatar}}/g, dataArray[index].avatar);
        }
        
        return listHtml;
    }
}

new Main();