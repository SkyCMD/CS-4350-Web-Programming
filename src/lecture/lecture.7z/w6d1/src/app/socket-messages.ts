export const SocketMessage = {
    Welcome: "Welcome to CS 4350 chat!",
    Disconnected: "You done just got disconnected bro.",
    Reconnected: "You have been retentered the matrix",
    UnableToReconnect: "Attempt to reconnect has failed."
};